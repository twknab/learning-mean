module.exports = function(mongoose, path){
	// sets up mongoose database
	var db = 'simpleServer'; // be sure to change this value for whatever database you'd like to use
	mongoose.connect('mongodb://localhost/' + db, function() {
		console.log('Connected to Mongo and ' + db + ' database! (...future connection and model loading now...)');
	});

	// scans all files in 'models' folder (be sure to check path below) and loads all files:
	var fs = require('fs');
	var models_path = path.join( __dirname, '/../models'); // make sure this path is correctly pointing to your models folder
	fs.readdirSync(models_path).forEach(function(file) {
		if (file.indexOf('.js') > 0) {
			require(models_path + '/' + file)(mongoose);
		}
	});
};