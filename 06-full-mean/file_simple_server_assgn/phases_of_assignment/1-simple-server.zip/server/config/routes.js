module.exports = function(mongoose, app){

	console.log('Future server routes loading...');

};