app.controller('indexController', ['$scope', 'friendFactory', '$location', function($scope, friendFactory, $location) {
  // Get data from Factory:
  function friends(data){
    $scope.friends = data;
    $scope.friend = {};
  };

  // Create:
  $scope.create = function(){
    friendFactory.create($scope.friend, friends);
    // By adding '$location' in the controller above, we can now use $location to
    // create a redirect to a new route. In the example  below we can actually just pass
    // '/' as this is already caught in our routes and will render the appropriate view.
    $location.url('/')
  };

  // Read (All):
  $scope.index = function(){
    friendFactory.index(friends);
  };
  // Invokes the function above to pass any existing Factory data to $scope:
  $scope.index();

  // Read (Single):
  $scope.show = function(id){
    friendFactory.show(id);
  };

  $scope.update = function(id){
    friendFactory.update(id, friends);
  };

  // Destroy:
  $scope.destroy = function(friend){
    console.log('destroying...');
    friendFactory.destroy(friend, friends);
  };

}]);