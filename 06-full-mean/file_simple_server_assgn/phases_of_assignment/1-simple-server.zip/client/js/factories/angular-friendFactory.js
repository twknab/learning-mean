app.factory('friendFactory', ['$http', function($http){
	var friends = [];
	var factory = {};

	// Create:
	factory.create = function(friend, callback){
		console.log(friend);
		friends.push(friend);
		callback(friends);
	};

	// Read (All):
	factory.index = function(callback){
		callback(friends);
	};

	// Read (Single):
	factory.show = function(id, callback){
		callback(friends);
	};

	// Update:
	factory.update = function(id, callback){
		callback(friends);
	};

	// Destroy:
	factory.destroy = function(friendToDelete, callback){
		// returns all friends who are not 'friendToDelete':
		friends = friends.filter(function(filteredUsers){
			return filteredUsers !== friendToDelete;
		});
		callback(friends);
	};

	return factory;
}]);