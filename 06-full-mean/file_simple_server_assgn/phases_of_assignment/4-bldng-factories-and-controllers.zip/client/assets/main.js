$(document).ready(function() {
	
    // Index Method (Get All) Controller Data:

	// Show Method Controller Data:

	// Create Method Controller Data:

	// Update Method Controller Data:

	// Delete Method Controller Data:
	
});