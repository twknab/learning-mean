app.factory('friendFactory', ['$http', function($http){
	// Construct our Factory Object
	var friends = [];
	var factory = {};

	// Create:
	// Note: these functions become a part of the 'factory' object above
	// there are a few different ways to construct this object, but this
	// has been my personal preference so far.
	factory.create = function(newFriend, callback){

		//////////////////////////////////////////////////////////////////
		////////////// C A L L    T O    D A T A B A S E /////////////////
		//////////////////////////////////////////////////////////////////

		$http.post('/friends', newFriend).then(function(returnData){
			console.log(returnData.data.newFriend);
			// friends.push(returnData.data.newFriend);
			// note: the line above would, if uncommented, send the data
			// to the 'friends' array defined at the top of this document.
			// This would make our object available to our views in angular,
			// however instead we are going to query the database to get all
			// friends and use this to update our view instead. Just wanting
			// to clarify to help in understanding how things are working.
			callback(returnData.data);
		});

		//////////////////////////////////////////////////////////////////
		///////////////// E N D     D B     C A L L //////////////////////
		//////////////////////////////////////////////////////////////////
	};

	// Read (All):
	factory.index = function(callback){

		//////////////////////////////////////////////////////////////////
		////////////// C A L L    T O    D A T A B A S E /////////////////
		//////////////////////////////////////////////////////////////////

		$http.get('/friends').then(function(returnData){
			console.log(returnData.data);
			friends = returnData.data.allFriends;
			callback(friends);
		});

		//////////////////////////////////////////////////////////////////
		///////////////// E N D     D B     C A L L //////////////////////
		//////////////////////////////////////////////////////////////////

	};

	// Read (Single):
	factory.show = function(id, callback){

		//////////////////////////////////////////////////////////////////
		////////////// C A L L    T O    D A T A B A S E /////////////////
		//////////////////////////////////////////////////////////////////

		$http.get('/friends/' + id).then(function(returnData){
			console.log(returnData.data);
			var foundFriend = returnData.data.foundFriend;
			console.log(foundFriend);

			var createdAt = new Date(foundFriend.createdAt);
			var updatedAt = new Date(foundFriend.updatedAt);

			foundFriend.birthday = new Date(foundFriend.birthday);
			foundFriend.strBirthday = foundFriend.birthday.toLocaleDateString();
			foundFriend.createdAt = createdAt.toLocaleDateString() + ' @ ' + createdAt.toLocaleTimeString();
			foundFriend.updatedAt = updatedAt.toLocaleDateString() + ' @ ' + updatedAt.toLocaleTimeString();

			callback(foundFriend);
		});

		//////////////////////////////////////////////////////////////////
		///////////////// E N D     D B     C A L L //////////////////////
		//////////////////////////////////////////////////////////////////

	};

	// Update:
	factory.update = function(id, updatedFriend){

		//////////////////////////////////////////////////////////////////
		////////////// C A L L    T O    D A T A B A S E /////////////////
		//////////////////////////////////////////////////////////////////

		$http.put('/friends/' + id, updatedFriend).then(function(returnData){
			console.log(returnData.data);
		});

		//////////////////////////////////////////////////////////////////
		///////////////// E N D     D B     C A L L //////////////////////
		//////////////////////////////////////////////////////////////////
	};

	// Destroy:
	factory.destroy = function(id){
		//////////////////////////////////////////////////////////////////
		////////////// C A L L    T O    D A T A B A S E /////////////////
		//////////////////////////////////////////////////////////////////

		console.log('about to run to DB...');
		$http.delete('/friends/' + id).then(function(returnData){
			console.log(returnData.data);
		});

		//////////////////////////////////////////////////////////////////
		///////////////// E N D     D B     C A L L //////////////////////
		//////////////////////////////////////////////////////////////////
	};

	return factory;
}]);