File Structure and Simple Server:

	The goal of this assignment is to build a simple Express server. Server should:

		+ Be able to serve static files from ./client, and ./bower_components.
		+ It should render index.html when a user hits the root route ‘/’ that has "Welcome" in the body.
		+ It should require body-parser.
		+ And you should be able to explain what body-parser does.
		+ It should require a mongoose.js file from “./server/config”. To confirm that the mongoose.js file loads have the top of this file console.log(‘future mongoose connection and model loading’);
		+ It should require a routes.js file from “./server/config”. To confirm that the routes.js loads have the routes.js console.log(‘future routes’). The routes.js file should export an empty function that has a parameter (app);
		+ It should listen at a port of your choosing.


	+ Work flow: Server > Model > API > Angular > Expand


Root ('/'):
	
	+ should load index.html which should load partials/index.html partial //DONE
	+ should build table with: //DONE
		+ Name //DONE
		+ Show (show) //DONE
		+ Update (edit) //DONE
		+ Delete (delete) //DONE
	+ birthday filter
	+ new friend button ('#/new')

    Controller Methods:

		+ index -> factory.index (build table)
		+ $scope.delete -> factory.delete (delete user)
		
	Other things:

		+ ng-route
		+ routeParams
		+ filter


Partial ('/#/new'):
	
	+ form:
		+ first name
		+ last name
		+ birthday picker (use jquery and jquery ui)
		+ 'create' submit button

	Controller Methods:

		+ $scope.create -> factory.create

	Other things:

		+ $location service
		+ ng-model
		+ ng-submit/ng-click


Partial ('/#/edit/:id'):

	+ form:
		+ first name (value filled in)
		+ last name (value filled in)
		+ birthday
		+ 'create' submit button

	Controller Methods:

		+ $scope.update -> factory.update
		+ show -> factory.show

	Other things:

		+ $location service
		+ routeParams


Partial ('/#/show/:id'):

	form:
		+ first name: (filled in)
		+ last name (filled in)
		+ birthday (filled in)
		+ user added (datetime filled in)

	Controller Methods:
		+ show -> factory.show

	Other things:

		+ $location service
		+ routeParams


Setup Project Folder:

	+ create blank server.js //DONE
	+ mkdir client //DONE
		+ mkdir client/assets //DONE
		+ mkdir client/partials //DONE
		+ touch client/index.html //DONE
	+ mkdir server //DONE
		+ mkdir server/config //DONE
			+ touch server/config/mongoose.js //DONE
			+ touch server/config/routes.js //DONE
		+ mkdir server/controllers //DONE
		+ mkdir server/models //DONE


Bower and NPM Setup and Dependencies:

	+ bower init //DONE
	+ bower install angular angular-route jquery --save //DONE
	+ npm init -y //DONE
	+ npm install express body-parser mongoose --save //DONE


Overall Idea:

	REQUEST FROM BROWSER -> SERVER ROUTE -> CONTROLLER -> FACTORY -> MODEL -> QUERY DATABASE -> UPDATE VIEWS


